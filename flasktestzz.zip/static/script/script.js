let darkmode = document.querySelector('#darkmode');

darkmode.onclick = () => {
    if(darkmode.classList.contains('bx-moon')){
        darkmode.classList.replace('bx-moon', 'bx-sun');
        document.body.classList.add('color');
    }else{
        darkmode.classList.replace('bx-sun', 'bx-moon');
        document.body.classList.remove('color');
    }
};

// responsive nav bar- without this nav will not appear:
let menu = document.querySelector('#menu-icon');
let navlist =  document.querySelector('.navlist');

menu.onclick = () => {
    menu.classList.toggle('bx-x');
    navlist.classList.toggle('open');
}

window.onscroll = () => {
    menu.classList.remove('bx-x');
    navlist.classList.remove('open');
}

const sr = ScrollReveal({
    distance: '70px',
    duration: 2700,
    reset: true
});

sr.reveal('.hero-text , .sec2, .sec2-2',{delay:200,origin:'bottom'});
sr.reveal('.hero-img',{delay:350,origin:'top'});

// date format:
$("#datePicker").on("change", function(e) {

    displayDateFormat($(this), '#datePickerLbl', $(this).val());
  
  });
  
  function displayDateFormat(thisElement, datePickerLblId, dateValue) {
  
    $(thisElement).css("color", "rgba(0,0,0,0)")
      .siblings(`${datePickerLblId}`)
      .css({
        position: "absolute",
        left: "10px",
        top: "3px",
        width: $(this).width()
      })
      .text(dateValue.length == 0 ? "" : (`${getDateFormat(new Date(dateValue))}`));
  
  }
  
  function getDateFormat(dateValue) {
  
    let d = new Date(dateValue);
  
    // this pattern dd/mm/yyyy
    // you can set pattern you need
    let dstring = `${("0" + d.getDate()).slice(-2)}/${("0" + (d.getMonth() + 1)).slice(-2)}/${d.getFullYear()}`;
  
    return dstring;
  }